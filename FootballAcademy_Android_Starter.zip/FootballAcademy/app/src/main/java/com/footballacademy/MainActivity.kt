package com.footballacademy

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val BarcaNavy = Color(0xFF101B3F)
private val BarcaBlue = Color(0xFF004D98)
private val BarcaRed = Color(0xFFA50044)
private val BarcaGold = Color(0xFFF5C542)
private val Page = Color(0xFF080F27)

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ReminderScheduler.schedule(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = BarcaGold,
                    secondary = BarcaRed,
                    background = Page,
                    surface = BarcaNavy
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AcademyHome(
                        onComplete = {
                            LessonProgress.markTodayComplete(this)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AcademyHome(onComplete: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var completed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        completed = LessonProgress.isTodayComplete(context)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Page)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("FOOTBALL ACADEMY", color = BarcaGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("أكاديميتك الكروية", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text("⚽", fontSize = 36.sp)
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = BarcaNavy),
            shape = RoundedCornerShape(22.dp)
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("درس اليوم", color = BarcaGold, fontWeight = FontWeight.Bold)
                Text("السنة 2000", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(
                    "بداية رحلتنا في تاريخ كرة القدم الحديث",
                    color = Color.LightGray,
                    fontSize = 14.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tag("التاريخ")
                    Tag("الأندية")
                    Tag("النجوم")
                }
                Button(
                    onClick = { },
                    colors = ButtonDefaults.buttonColors(containerColor = BarcaRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ابدأ الدرس")
                }
            }
        }

        Text("محطات اليوم", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        InfoCard("🏆", "دوري أبطال أوروبا", "ريال مدريد توّج بلقب موسم 1999–2000 بعد الفوز على فالنسيا في النهائي.")
        InfoCard("🌍", "بطولة أمم أوروبا", "فرنسا فازت بيورو 2000 بعد هدف دافيد تريزيغيه الذهبي في النهائي أمام إيطاليا.")
        InfoCard("⭐", "نجوم بارزون", "زين الدين زيدان، لويس فيغو، راؤول، دافيد تريزيغيه، وفرانشيسكو توتي من أبرز الأسماء في تلك الفترة.")

        Card(colors = CardDefaults.cardColors(containerColor = if (completed) Color(0xFF174B3A) else BarcaBlue)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (completed) "أحسنت! أنهيت درس اليوم ✓" else "خلصت درس النهارده؟",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (completed) "التذكيرات هتتوقف لحد الدرس القادم." else "علّم الدرس كمكتمل لإيقاف التذكيرات.",
                    color = Color.White
                )
                Button(
                    onClick = {
                        onComplete()
                        completed = true
                    },
                    enabled = !completed,
                    colors = ButtonDefaults.buttonColors(containerColor = BarcaGold, contentColor = BarcaNavy),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (completed) "تم الإكمال" else "إكمال درس اليوم")
                }
            }
        }

        Text("الإصدار الأول: واجهة أولية + تذكيرات + حفظ حالة الدرس", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun Tag(text: String) {
    Surface(color = BarcaRed, shape = RoundedCornerShape(50)) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), color = Color.White, fontSize = 11.sp)
    }
}

@Composable
private fun InfoCard(emoji: String, title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF131F45))) {
        Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(emoji, fontSize = 24.sp)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = BarcaGold, fontWeight = FontWeight.Bold)
                Text(body, color = Color.White, fontSize = 13.sp, lineHeight = 19.sp)
            }
        }
    }
}
