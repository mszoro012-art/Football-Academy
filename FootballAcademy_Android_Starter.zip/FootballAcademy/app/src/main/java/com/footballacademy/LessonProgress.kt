package com.footballacademy

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LessonProgress {
    private const val PREFS = "football_academy_progress"
    private const val KEY_COMPLETED_DATE = "completed_date"

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun markTodayComplete(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_COMPLETED_DATE, today())
            .apply()
    }

    fun isTodayComplete(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_COMPLETED_DATE, "") == today()
}
